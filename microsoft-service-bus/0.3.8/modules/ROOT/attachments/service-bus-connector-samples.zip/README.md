Microsoft Service Bus Connector Demo
====================================
Mule Studio demo for Microsoft Service Bus connector. This sample contains two scenarios: one for the management API that allows to create Topics, Subscriptions and Rules, and the one for the AMQP part of the connector that allows to send and receive messages based on different filters.


Management API Sample
---------------------

This sample shows how to consume the Service Bus Management Web APIs from a flow to create and configure Topics.

Prerequisites
---------------

A running instance of Azure Service Bus or Windows Service Bus with a Namespace already created.

How to Run Sample
-----------------

1. Import the project folder servicebus-management-demo in Studio.
2. Update the Microsoft Service Bus connection parameters in /src/main/app/mule-app.properties.
3. From the 'Global Elements' tab, open the Microsoft_Service_Bus__Azure_Service_Bus connection.
4. Click on 'Test Connection' to make sure the connection works correctly.
5. Run the application.

About the Sample
----------------

The flow exposes different operations through an Http Connector. The following list enumerates the supported operations and the
associated URL.

* Create a new topic: http://localhost:8081/topic?topicPath={topicPath}
* Create a new subscription: http://localhost:8081/subscription?topicPath={topicPath}&subscriptionPath={subscriptionPath}
* Updates the default filter rule to filter for a property called "priority": http://localhost:8081/rule?topicPath={topicPath}&subscriptionPath={subscriptionPath}&priority={priority}


AMQP sample
-----------

This sample illustrates how to consume messages from Service Bus topics configured with different filters using an AMQP connection.  

Prerequisites
---------------

* A running instance of Azure Service Bus or Windows Service Bus with a Namespace already created.
* A topic created with three subscriptions.
* A subscription HighPriority with the default filter ($Default) set to "priority = HIGH".
* A subscription MediumPriority with the default filter ($Defult) set to "priority = MEDIUM".
* A subscription LowPriority with the default filter ($Default) set to "priority = LOW".

The topic, subscriptions and rules can be created with the Management API Demo.

How to Run Sample
-----------------

1.	Import the project folder servicebus-amqp-demo in Studio.
2.	Update the Service Bus connection parameters in /src/main/app/mule-app.properties. Note: By default, Azure configuration is used in the flows. If running against windows service bus, change the Connector Configuration of all Microsoft Service Bus Connectors to Microsoft_Service_Bus__Windows_Service_Bus
3.	Set the topic path property in /src/main/app/mule-app.properties
4.	From the 'Global Elements' tab, open the Microsoft_Service_Bus__Azure_Service_Bus connection.
5.	Click on 'Test Connection' to make sure the connection works correctly.
6.	Run the application.

About the Sample
----------------

This sample consists of a flow for sending messages to the configured topic and three other flows that are receiving messages for each of the subscriptions (HighPriority, MediumPriority and LowPriority).

The flow for sending messages exposes an Http endpoint, which can be hit with the following URL: http://localhost:8081/NewMessage?amqp.priority={priority}

By default, only the HighPriority flow is started. So, if a message is send with the priority HIGH, it will be received and logged in the console, otherwise it will not be received.

To receive messages with MEDIUM or LOW priority, click on the flow and change its initial state to "started".

Messages with priority different than HIGH, MEDIUM or LOW will not be received in this sample.
