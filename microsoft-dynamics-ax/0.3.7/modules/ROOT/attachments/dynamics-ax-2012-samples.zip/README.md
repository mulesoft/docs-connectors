Microsoft Dynamics AX Connector Demo
====================================

Mule Studio demo for Microsoft Dynamics AX connector.

How to Run the Demo
-------------------

1. Import the project folder in Studio.  
2. Update the Microsoft Dynamics AX connection parameters in /src/main/app/mule-app.properties.  
3. Click on 'Test Connection' to make sure the connection works correctly.  
4. Run the application.  


About the Demo
--------------

The demo includes the following operations:
* Query all projects from 'ProjTable' table: http://localhost:8081/projects
* List all projects (static query 'ProjListProjectTable'): http://localhost:8081/list-projects
* Get project by ProjId (static query 'ProjListProjectTable'): http://localhost:8081/list-projects?ProjId={ProjId}