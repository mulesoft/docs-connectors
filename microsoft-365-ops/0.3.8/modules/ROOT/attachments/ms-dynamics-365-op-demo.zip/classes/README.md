Microsft Dynamics 365 for Operations Connector Demo
=======================================

INTRODUCTION
------------
This demo is going to demonstrate the use of Microsft Dynamics 365 for Operations Connector.


HOW TO RUN DEMO
---------------

### Prerequisites

In order to build and run this demo project you'll need:

* Anypoint Studio with at least Mule ESB 3.7 Runtime.
* Microsft Dynamics 365 for Operations Connector v1.0.0 or higher.
* Dynamics 365 for Operations

### Test the flows

1. Import the demo project into your workspace via "Anypoint Exchange" or "Import..." from "File" menu.
2. Specify your OAuth2 credentials for 'OAuth2 Username Password' Config in /src/main/app/mule-app.properties

	* `dynamics365.username` - Username used to initialize the session
	* `dynamics365.password` - Password used to authenticate the user
	* `dynamics365.resource` - The App ID URI of the web API (secured resource). It must be root URI (Example: `https://<your-org>.operations.dynamics.com/`)
	* `dynamics365.clientId` - The Application Id assigned to your app when you registered it with Azure AD. You can find this in the Azure Portal. Click Active Directory, click the directory, choose the application, and click Configure.
	* `dynamics365.clientSecret` - The Application Secret that you created in the app registration portal for your app. It should not be used in a native app, because `client_secret` cannot be reliably stored on devices. It is required for web apps and web APIs, which have the ability to store the client_secret securely on the server side.
	* `dynamics365.tokenRequestEndpoint` - The token endpoint that is called to get the access token. (Example: `https://login.windows.net/<tenant-id>/oauth2/token` where 'tenant-id' is the Azure AD id)

3. Make sure you specify 'DataSense Connection Timeout' with more than 200 seconds because the connector makes several requests to provide DataSense information.
	
4. Run the project in Studio.
5. Type `localhost:8081` in your browser to access the selection menu of the demo.
6. Optionally you can configure the Connection Timeout and Read Timeout. 
	The Connection Timeout is the timeout in making the initial connection with the server. 
	The Read Timeout is the timeout on waiting to read data from the server.
	
	
ABOUT THE DEMO
---------------
	
1. `IMPORT_DATA_RECURRING_JOB_DEMO`: This flow imports data for a recurring job.
	You should create first a recurring data job for a specific entity using a specific source data format.
    The entitiy name, activity id and a file containg the data to be imported must be provided.

	[POST] The HTTP endpoint listens to the following URL: `http://localhost:8081/import`

2. `RETRIEVE_MULTIPLE_BY_URL`: This flow retrieves multiple entities based on url request.
	You should create a few customer accounts first.

	[GET] The HTTP endpoint listens to the following URL: `http://localhost:8081/retrieveCustomers`

3. `RETRIEVE_MULTIPLE_BY_DSQL`: This flow retrieves multiple entities based on Datasense Query Language.
	You should create a few customer accounts first.

	[GET] The HTTP endpoint listens to the following URL: `http://localhost:8081/retrieveCustomersByQuery`

4. `APPLY_TIMEZONE`: This flow applies the timezone based on the dateTime and timezoneOffset provided.

	[POST] The HTTP endpoint listens to the following URL: `http://localhost:8081/applyTimezone`

You can use the selection menu from `http://localhost:8081` to test the flows or you can POST JSONs using a tool like curl, or any other tool (Chrome/Mozilla Firefox extensions) that lets you POST a body when calling the URL.
