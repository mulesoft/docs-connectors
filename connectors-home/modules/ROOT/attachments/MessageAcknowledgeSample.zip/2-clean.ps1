[Reflection.Assembly]::LoadWithPartialName("System.Messaging") | out-null 

Function DeleteQueue
{
  param
  (
    [string]$path
  )

    if ([System.Messaging.MessageQueue]::Exists($path))
    {
        Write-Host "Deleting $path Queue"
        [System.Messaging.MessageQueue]::Delete($path)
    }
}

DeleteQueue ".\private$\sampleq" 
DeleteQueue ".\private$\secondq" 
DeleteQueue ".\private$\adminq" 