Microsoft SharePoint 2010 Connector Demo
=====================================

Mule Studio demo for Microsoft SharePoint 2010 connector.

How to Run Demo
---------------

1. Import the project folder in Studio.  
2. Update the Microsoft SharePoint 2010 connection parameters in /src/main/app/mule-app.properties.    
4. Set a valid folder path for 'output.folder.path' in /src/main/app/mule-app.properties.  
4. From the 'Global Elements' tab, open the 'Sharepoint' connection.  
5. Click on 'Test Connection' to make sure the connection works correctly.  
6. Run the application.  


About the Demo
--------------

The demo includes the following options:
Lists and list items API:
* Create a new list that uses the base template 'GENERIC_LIST' with title specified by 'title' parameter: http://localhost:8081/create-list?title={title}
* Create a new list item with title specified by the 'title' parameter and in the list specified by the 'listName' parameter : http://localhost:8081/create-list-item?listName={listName}&title={title}
* Query list items by title resolving every lookup objects (full tree): http://localhost:8081/list-item-query?listName={listName}&title={title}
* Delete the list specified by the 'title' parameter: http://localhost:8081/delete-list?listName={listName}

Files and folders API:
* Create a new folder in the specified url (e.g.: Shared Documents/new folder): http://localhost:8081/create-folder?folderServerRelativeUrl={folderServerRelativeUrl}       
* Retrieve all folders from the 'Shared Documents' library and resolves the author reference after the execution of the query: http://localhost:8081/query-folder
* Uploads a file to 'Shared Documents' library with the specified title and content: http://localhost:8081/file-upload?fileName={fileName}&contentString={contentString}
* Download all files from the 'Shared Documents' folder to the configured 'output.folder.path': http://localhost:8081/files-download
* Upload an image to a Picture Library: http://localhost:8081/image-upload?pictureListTitle={pictureListTitle}
* Delete the specified folder: http://localhost:8081/delete-folder?folderServerRelativeUrl={folderServerRelativeUrl}

