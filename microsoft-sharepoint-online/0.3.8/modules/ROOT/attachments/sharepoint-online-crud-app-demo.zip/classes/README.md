Sharepoint Online crud-app Demo
====================================
