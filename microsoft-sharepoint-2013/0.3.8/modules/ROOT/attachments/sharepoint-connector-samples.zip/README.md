Microsoft SharePoint Connector Demo
=====================================

Mule Studio demo for Microsoft SharePoint connector.

How to Run Demo
---------------

1. Import the project folder in Studio.  
2. Update the Microsoft SharePoint connection parameters in /src/main/app/mule-app.properties.    
4. Set a valid folder path for 'output.folder.path' in /src/main/app/mule-app.properties.  
4. From the 'Global Elements' tab, open the 'Sharepoint' connection.  
5. Click on 'Test Connection' to make sure the connection works correctly.  
6. Run the application.  


About the Demo
--------------

The demo includes the following options:
Lists and list items API:
* Create a new list that uses the base template 'GENERIC_LIST': http://localhost:8081/create-list?title={title}
* Create a new list item: http://localhost:8081/create-list-item?listId={listId}&title={title}
* Query list items by title: http://localhost:8081/list-item-query?listId={listId}&title={title}&retrieveReferences={true|false}
* Delete a list: http://localhost:8081/delete-list?listId={listId}

Files and folders API:
* Create a new folder: http://localhost:8081/create-folder?folderServerRelativeUrl={folderServerRelativeUrl}
* Retrieve all folders that have an item from a document or picture list: http://localhost:8081/query-folder
* Download all files from the 'Shared Documents' folder to the configured 'output.folder.path': http://localhost:8081/files-download
* Upload an image to a Picture List: http://localhost:8081/image-upload?pictureListTitle={pictureListTitle}
* Delete a folder: http://localhost:8081/delete-folder?folderServerRelativeUrl={folderServerRelativeUrl}

Direct API access:
* Resolve object: http://localhost:8081/resolve-object?listId={listId}
* Resolve collection: http://localhost:8081/resolve-collection
