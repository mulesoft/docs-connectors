Zuora Aggregate Query API Demo (AQuA)
=======================================

INTRODUCTION
------------
This demo is going to demonstrate the use of Aggregate Query API with Zuora Connector.

HOW TO RUN DEMO
---------------

### Prerequisites

In order to build and run this demo project you'll need:

* Anypoint Studio with at least Mule ESB 3.5 Runtime.
* Mule Zuora Connector v3.1.0 or higher.

### Test the flows

1. Import the demo project into your workspace via "Anypoint Exchange" or "Import..." from "File" menu.
2. Specify your Zuora credentials in /src/main/app/mule-app.properties
	* config.username - user name within Zuora system
	* config.password - password within Zuora system
	* config.endpoint - the endpoint called by the Zuora Soap operations
	* config.restEndpoint - the endpoint called by the Zuora Rest operations
	* config.wsdlLocation - the location of the Zuora WSDL
3. Run the project in Studio.
4. Type `localhost:8081` in your browser to access the selection menu of the demo.
5. Optionally you can configure the Read Timeout and Connection Timeout. 
	The connection timeout is the timeout in making the initial connection with the server. 
	The read timeout is the timeout on waiting to read data from the server.


ABOUT THE DEMO
---------------

1. `aqua-api-post-query-demo`: Choose 'Post Multiple Query' in the selection menu.
This flow can execute one Export ZOQL and ZOQL at the same time. You must specify a Job Name, Project Id and Partner Id fields being optional and if specified
AQUA will be executed in Stateful mode, establishing a continuous session across a series of requests. If not provided, AQUA will be executed in Stateless mode;
Read more about Stateless/Stateful Modes [here](https://knowledgecenter.zuora.com/DC_Developers/Aggregate_Query_API/BA_Stateless_and_Stateful_Modes "here").

	For this operation you can also configure 'Entity Id' and 'Entity Name' for Multi-entity support. Read more about Multi-entity [here](https://knowledgecenter.zuora.com/BB_Introducing_Z_Business/Multi-entity).

2. `aqua-api-get-job-results-demo`: Choose 'Get Job Results Demo' in the selection menu.
This flow will return the representation of a Job, having the status for the Job and a list of Batches. Each Batch contains information about a single query that was
submitted. If a query has the field status with the value 'completed' it will also contain an additional field called "fileId". With the "Get export file stream" operation, the connector can retrieve the query results from a specified 'fileId'.
This operation also has Multi-entity support.

3. `aqua-api-get-last-completed-job-demo`: Choose 'Get Last Completed Job'
This flow will return the representation of the last completed job. This operation will work only for jobs in stateful mode, so the GetLastJobRequest needs the partnerId and the projectId to give back a response. This operation also has Multi-entity support.

4. `aqua-post-query-results-to-object-store`: Choose 'Post Query Results to Object Store'. This flow uses the 'Aqua post query' operation and it requires a PostQueryResponse for input. For this operation we checked 'Save Job To Object Store' and we named it 'PostQueryResultsStore' in the 'Object Store Reference' configuration input. If no name is specified, the default object store will be used. 

5. `aqua-polling-demo`: This flow works behind the scene, and it processes the jobs saved with the 'Aqua post query' operation in the 'PostQueryResultsStore' object store.

	5.1 The 'Aqua get batch results' operation goes to each job found in the Object Store (the Object Store can be named by the user in the operation configuration; if no name is specified, the default object store will be processed) and periodically checks if the job is completed (the polling period can be configured by the user using the field 'Polling Period')

	5.2 When a completed job is found the source returns it as an Object.

	5.3 'Aqua get job metadata' operation receives the Object as the input and will output the representation of a Job so Datasense can be used.

	5.4 The 'For Each' component goes to each batch from the job and the fileId of the batch is exported to be used by the 'Get export file stream' operation.

	5.5 The 'Get export file stream' operation will access the results for the given fileId and return them as a stream.

	5.6 The 'Copy to file' component will take each stream and save it in a file named <fileId> in `src/test/resources`.