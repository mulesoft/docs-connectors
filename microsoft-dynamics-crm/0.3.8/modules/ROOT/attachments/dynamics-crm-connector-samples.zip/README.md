Microsoft Dynamics CRM Connector Demo
=====================================

Mule Studio demo for Microsoft Dynamics CRM connector.

How to Run Demo
---------------

1. Import the project folder in Studio.  
2. Update the Microsoft Dynamics CRM connection parameters in /src/main/app/mule-app.properties.  
3. Click on 'Test Connection' to make sure the connection works correctly.  
4. Run the application.  


About the Demo
--------------

The demo includes the following options:
* Return all accounts: http://localhost:8081/accounts
* Query accounts by name containing a substring: http://localhost:8081/query-accounts?name=li
* Create a new account with the specified name: http://localhost:8081/create-account?name=your-account-name
* Delete an account: http://localhost:8081/delete-account?accountid={account-guid}
* Return all contacts: http://localhost:8081/contacts
* Return all contacts for an account: http://localhost:8081/contacts-by-account?accountid={account-guid}
* Associate a contact to an account: http://localhost:8081/associate?accountid={account-guid}&contactid={contact-guid}
* Disassociate a contact from an account: http://localhost:8081/disassociate?accountid={account-guid}&contactid={contact-guid}
* Create an opportunity: http://localhost:8081/create-opportunity?accountid={account-guid}&contactid={contact-guid}
* Query opportunities by parent account: http://localhost:8081/opportunities-by-account?accountid={account-guid}
* Activate an account by executing the SetState operation: http://localhost:8081/activate-account?id={account-guid}
* Deactivate an account by executing the SetState operation: http://localhost:8081/deactivate-account?id={account-guid}
* Create multiple entities in a single request: http://localhost:8081/create-multiple
* Update a the property 'Description' of multiple contacts in a single request: http://localhost:8081/update-multiple
* Delete multiple contacts in a single request: http://localhost:8081/delete-multiple